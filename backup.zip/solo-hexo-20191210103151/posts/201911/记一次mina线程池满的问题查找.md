title: 记一次mina线程池满的问题查找
date: '2019-11-13 16:32:16'
updated: '2019-11-13 16:32:31'
tags: [Mina, Thread, Arthas, Java]
permalink: /articles/2019/11/13/1573633935984.html
---
# 问题情况
当访问服务端口时mina无法分配可用线程到新的连接中.
# 线程状态
通过[arthas](http://39.107.41.216/articles/2019/11/05/1572916866300.html)检查线程状态确认到mina线程池将所有线程分配了,mina初始化时设置的线程池参数为100个线程,全部进入到`TIMED_WAITING`中
```log
"pool-13-thread-22" prio=10 tid=0x00007f0c1410c000 nid=0x62ad in Object.wait() [0x00007f0cf6cf9000]
   java.lang.Thread.State: TIMED_WAITING (on object monitor)
	at java.lang.Object.wait(Native Method)
	- waiting on <0x00000007842d8c50> (a org.apache.mina.core.future.DefaultWriteFuture)
	at org.apache.mina.core.future.DefaultIoFuture.await0(DefaultIoFuture.java:192)
	- locked <0x00000007842d8c50> (a org.apache.mina.core.future.DefaultWriteFuture)
	at org.apache.mina.core.future.DefaultIoFuture.awaitUninterruptibly(DefaultIoFuture.java:133)
	at org.apache.mina.core.future.DefaultWriteFuture.awaitUninterruptibly(DefaultWriteFuture.java:112)
	at org.apache.mina.handler.stream.IoSessionOutputStream.flush(IoSessionOutputStream.java:84)
	- locked <0x00000007842d8c78> (a org.apache.mina.handler.stream.IoSessionOutputStream)
	at java.io.BufferedOutputStream.flush(BufferedOutputStream.java:141)
	- locked <0x00000007842d8c90> (a java.io.BufferedOutputStream)
	......
```
# 追究根本原因
mina的`IoSessionOutputStream.flush`方法,实际为等待无限长时间,直到mina将`IoBuffer`中的数据全部发送完毕后对等待进行唤醒  

但是存在一个检查服务存活的程序,负责每隔几秒钟对服务进行连接测试,连接上就断开,程序发送欢迎信息还没有结束就断开了连接,造成mina无法将存储在IoBuffer中的信息发送,也就无法唤醒阻塞等待,造成线程卡死
## IoSessionOutputStream.flush
```java
@Override
    public synchronized void flush() throws IOException {
        if (lastWriteFuture == null) {
            return;
        }

        lastWriteFuture.awaitUninterruptibly();
        if (!lastWriteFuture.isWritten()) {
            throw new IOException("The bytes could not be written to the session");
        }
    }
```
## DefaultIoFuture.await0
```java
/**
     * Wait for the Future to be ready. If the requested delay is 0 or
     * negative, this method immediately returns the value of the
     * 'ready' flag.
     * Every 5 second, the wait will be suspended to be able to check if
     * there is a deadlock or not.
     * 
     * @param timeoutMillis The delay we will wait for the Future to be ready
     * @param interruptable Tells if the wait can be interrupted or not
     * @return <tt>true</tt> if the Future is ready
     * @throws InterruptedException If the thread has been interrupted
     * when it's not allowed.
     */
    private boolean await0(long timeoutMillis, boolean interruptable) throws InterruptedException {
        long endTime = System.currentTimeMillis() + timeoutMillis;

        if (endTime < 0) {
            endTime = Long.MAX_VALUE;
        }

        synchronized (lock) {
            // We can quit if the ready flag is set to true, or if
            // the timeout is set to 0 or below : we don't wait in this case.
            if (ready||(timeoutMillis <= 0)) {
                return ready;
            }

            // The operation is not completed : we have to wait
            waiters++;

            try {
                for (;;) {
                    try {
                        long timeOut = Math.min(timeoutMillis, DEAD_LOCK_CHECK_INTERVAL);
                        
                        // Wait for the requested period of time,
                        // but every DEAD_LOCK_CHECK_INTERVAL seconds, we will
                        // check that we aren't blocked.
                        lock.wait(timeOut);
                    } catch (InterruptedException e) {
                        if (interruptable) {
                            throw e;
                        }
                    }

                    if (ready || (endTime < System.currentTimeMillis())) {
                        return ready;
                    } else {
                        // Take a chance, detect a potential deadlock
                        checkDeadLock();
                    }
                }
            } finally {
                // We get here for 3 possible reasons :
                // 1) We have been notified (the operation has completed a way or another)
                // 2) We have reached the timeout
                // 3) The thread has been interrupted
                // In any case, we decrement the number of waiters, and we get out.
                waiters--;
                
                if (!ready) {
                    checkDeadLock();
                }
            }
        }
    }
```
