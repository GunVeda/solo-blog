title: drools规则引擎写法
date: '2019-11-05 09:16:39'
updated: '2019-11-05 09:16:39'
tags: [drools, 笔记, 规则引擎]
permalink: /articles/2019/11/05/1572916598836.html
---
![](https://img.hacpai.com/bing/20181201.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

# drools

规则引擎

## 语法

### 关键字

#### Package

##### package

包定义,规则文件的第一行

```drools
package aaa
```



##### import

引入资源,和java`import`一样

```drools
import java.util.List
```



##### global

1. 定义规则全局变量

   ```drools
   global java.util.List myGlobalList;
   
   rule "Using a global"
   when
     eval( true )
   then
     myGlobalList.add( "Hello World" );
   end
   ```

   

2. 在过程中添加全局变量

   ```drools
   List list = new ArrayList();
   KieSession kieSession = kiebase.newKieSession();
   kieSession.setGlobal( "myGlobalList", list );
   ```

   

#### Function

##### function

1. 定义规则文件中的方法

   ```drools
   function String hello(String name) {
     return "Hello "+name+"!";
   }
   import function my.package.Foo.hello
   rule "using a static function"
   when
     eval( true )
   then
     System.out.println( hello( "Bob" ) );
   end
   ```

   

#### Query

##### query

1. 搜索工作内存中与指定条件匹配的事实的简单方法

   ```drools
   对所有30岁以上的人的简单查询
   query "people over the age of 30"
       person : Person( age > 30 )
   end
   
   查询超过x岁的人,以及居住在y的人
   query "people over the age of x"  (int x, String y)
       person : Person( age > x, location == y )
   end
   
   QueryResults results = ksession.getQueryResults( "people over the age of 30" );
   System.out.println( "we have " + results.size() + " people over the age  of 30" );
   
   System.out.println( "These people are are over 30:" );
   
   for ( QueryResultsRow row : results ) {
       Person person = ( Person ) row.get( "person" );
       System.out.println( person.getName() + "\n" );
   }
   ```

#### Rule

##### rule

定义规则,一个规则包含三个部分:属性部分,条件部分(LHS),结果部分(RHS)

```drools
rule "ruleName"
```

#### Attributes

##### no-loop

- 默认值:false
- 类型:Boolean
- 功能: 当true时允许其他规则通过update()更新其相关的Fact对象对规则进行二次执行

##### ruleflow-group

- 默认值:N/A
- 类型:String
- 功能:`Ruleflow`是一个Drools功能,可让您控制规则的触发.由相同的规则流组标识汇编的规则仅在其组处于活动状态时触发.将规则划分为一个个的组,然后在规则流当中通过使用`ruleflow-group`属性的值,从而使用对应的规则.

##### lock-on-active

- 默认值:false
- 类型:Boolean
- 功能:避免Fact对象变更造成的规则二次执行

##### salience

- 默认值:0
- 类型:Integer
- 功能:设置规则的执行优先级,数字越大优先级越高,可以为负数

##### agenda-group

- 默认值:MAIN
- 类型:String
- 功能:分组获取焦点执行,没有焦点的情况下,该分组将不执行.

##### auto-focus

- 默认值:false
- 类型:Boolean
- 功能:规则中写明,当前规则自动获得焦点,不用显示写明焦点,可以实现` org.drools.runtime.rule.AgendaFilter `的`accept`方法控制规则是否执行

##### activation-group

- 默认值:N/A
- 类型:String
- 功能:规则分组,当一组中只要有一个规则被执行,该组的其他规则将不再执行

##### dialect

- 默认值:根据package指定
- 类型:String, “java”or”mvel“
- 功能:表示用于LHS和RHS代码块中的任何代码表达式的方言.目前有两种方言,`java`和`MVEL`.虽然方言可以在包级别指定,但此属性允许为规则覆盖包定义

##### date-effective

- 默认值:N/A
- 类型:字符串,包含日期和时间定义.格式:`dd-MMM-yyyy`(25-Sep-2009)
- 功能: 仅当当前日期和时间在设定的时间后面时,才能激活规则. 

##### date-expires

- 默认值:N/A
- 类型:字符串,包含日期和时间定义.格式:`dd-MMM-yyyy`(25-Sep-2009)
- 功能:仅当当前日期和时间在设定的时间前面时,才能激活规则. 

##### enabled

- 默认值:true
- 类型:String
- 功能:表示规则可以使用,如果手工为规则添加`enabled`属性,并且设置为`false`,该规则将不会执行

##### duration

- 默认值:无
- 类型:Long
- 功能: 将在指定的持续时间之后触发,如果它仍然是true. 

### 条件部分-LHS

定义当前规则的条件,如`when Message()`; 判断当前workingMemory中是否存在Message对象.

`Left Hand Side`（`LHS`）是规则的条件部分的公共名称.它由零个或多个条件元素组成.
 如果LHS为空,它将被认为是一个条件元素,它总是为真,并且当创建一个新的WorkingMemory会话时,它将被激活一次.

```drools
    Conditions / LHS —匹配模式（Patterns）

    没有字段约束的Pattern
    Person()

    有文本字段约束的Pattern
    Person( name == “bob” )

    字段绑定的Pattern
    Person( $name : name == “bob” )
    变量名称可以是任何合法的java变量,$是可选的,可由于区分字段和变量

    Fact绑定的Pattern
    $bob : Person( name == “bob” )字段绑定的Pattern

    变量约束的Pattern
    Person( name == $name )
```

Drools提供了十二种类型比较操作符:
 `>`  `>=`  `<`  `<=`  `==`  `!=`  `contains`  `not contains`  `memberOf`  `not memberOf` `matches` `not matches`

####  contains 

-  用于检查作为Collection或elements的字段是否包含指定的值 

  ```drools
  Cheese( name contains "tilto" )
  Person( fullName contains "Jr" )
  String( this contains "foo" )
  ```

#### not contains

- 与`contains`相反

####  memberOf 

-  用于检查字段是否是集合的成员或元素;该集合必须是一个变量. 

  ```drools
  CheeseCounter( cheese memberOf $matureCheeses )
  ```

####  not memberOf 

- 与` memberOf `相反

####  matches 

-  正则表达式匹配,与java不同的是,不用考虑'/'的转义问题 

  ```drools
  Cheese( type matches "(Buffalo)?\\S*Mozarella" )
  ```

#### not matches

- 与`matches`相反

#### exists

-  存在.检查Working Memory是否存在某物.使用模式`exists`,则规则将只激活最多一次,而不管在工作存储器中存在与存在模式中的条件匹配的数据量 

#### not

-  不存在,检查工作存储器中是否存在某物.

### 结果部分-RHS

这里可以写普通java代码,即当前规则条件满足后执行的操作,可以直接调用Fact对象的方法来操作应用.

`Right Hand Side`（`RHS`）是规则的结果或动作部分的通用名称;此部分应包含要执行的操作的列表.在规则的RHS中使用命令式或条件式代码是不好的做法;作为一个规则应该是`原子`的性质 - “`when this, then do this`”,而不是“`when this, maybe do this`”.规则的RHS部分也应该保持较小,从而保持声明性和可读性.如果你发现你需要在RHS中的命令式和/或条件代码,那么也许你应该把这个规则分成多个规则. `RHS`的主要目的是插入,删除或修改工作存储器数据.为了协助,有一些方便的方法可以用来修改工作记忆;而不必首先引用工作内存实例.

#### update

-  更新,告诉引擎对象已经改变（已经绑定到LHS上的某个东西）,并且规则可能需要重新考虑.

#### insert(new Something())

- 插入,往当前`workingMemory`中插入一个新的Fact对象,会触发规则的再次执行,除非使用`no-loop`限定.

####  insertLogical(new Something())

-  类似于`insert`,但是当没有更多的facts支持当前触发规则的真实性时,对象将被自动删除.

#### modify

-  修改,与`update`语法不同,结果都是更新操作.该语言扩展提供了一种结构化的方法来更新事实.它将更新操作与一些setter调用相结合来更改对象的字段. 

####  retract

- 删除

#### drools.halt()

- 调用`drools.halt（）`立即终止规则执行.这是需要将控制权返回到当前会话使用`fireUntilHalt（）`的点.

#### drools.getWorkingMemory()

- 返回WorkingMemory对象.

#### drools.setFocus( String s)

- 将焦点设置为指定的`agenda group`.

#### drools.getRule().getName()

- 从规则的RHS调用,返回规则的名称.

#### drools.getTuple()

- 返回与当前执行的规则匹配的`Tuple`,而drools.getActivation（）传递相应的激活.
