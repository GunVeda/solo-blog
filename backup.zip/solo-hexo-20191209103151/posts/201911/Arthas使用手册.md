title: Arthas使用手册
date: '2019-11-05 09:21:06'
updated: '2019-11-05 15:09:16'
tags: [Java, 笔记, Arthas, 使用手册]
permalink: /articles/2019/11/05/1572916866300.html
---
![](https://img.hacpai.com/bing/20190717.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

# Arthas使用手册

`Arthas`是Alibaba开源的Java诊断工具，深受开发者喜爱。

当你遇到以下类似问题而束手无策时，`Arthas`可以帮助你解决：
1. 这个类从哪个 jar 包加载的？为什么会报各种类相关的 Exception？
2. 我改的代码为什么没有执行到？难道是我没 commit？分支搞错了？
3. 遇到问题无法在线上 debug，难道只能通过加日志再重新发布吗？
4. 线上遇到某个用户的数据处理有问题，但线上同样无法 debug，线下无法重现！
5. 是否有一个全局视角来查看系统的运行状况？
6. 有什么办法可以监控到JVM的实时运行状态？

Arthas支持JDK 6+，支持Linux/Mac/Winodws，采用命令行交互模式，同时提供丰富的 Tab 自动补全功能，进一步方便进行问题的定位和诊断。

# 在线文档
[官方文档](https://alibaba.github.io/arthas)

# 安装
## 安装方式一
使用`arthas-boot`

下载arthas-boot.jar，然后用java -jar的方式启动：
```shell
wget https://alibaba.github.io/arthas/arthas-boot.jar
java -jar arthas-boot.jar
```

## 安装方案二
使用`as.sh`
`Arthas`支持在`Linux/Unix/Mac`等平台上一键安装，请复制以下内容，并粘贴到命令行中，敲`回车`执行即可：
```shell
curl -L https://alibaba.github.io/arthas/install.sh | sh
```

## 安装方案三(离线式安装)
### 下载最新版本
地址:[Arthas](http://repository.sonatype.org/service/local/artifact/maven/redirect?r=central-proxy&g=com.taobao.arthas&a=arthas-packaging&e=zip&c=bin&v=LATEST)

如果下载速度比较慢，可以尝试用阿里云的镜像仓库，比如要下载3.x.x版本（替换3.x.x为最新版本），下载的url是：
```url
https://maven.aliyun.com/repository/public/com/taobao/arthas/arthas-packaging/3.x.x/arthas-packaging-3.x.x-bin.zip
```
### 解压缩arthas的压缩包
```shell
unzip arthas-packaging-bin.zip
```
### 安装Arthas
安装之前最好把所有老版本的Arthas全都删掉
```shell
su admin
rm -rf /home/admin/.arthas/lib/*
cd arthas
./install-local.sh
```
注意，这里根据你需要诊断的Java进程的所属用户进行切换(arthas无法跨用户进行监听,即便使用root账户也无法监听其他账户启动的java进程)
### 启动Arthas
启动之前，请确保老版本的Arthas已经shutdown.
```shell
~/.arthas/lib/3.1.0/arthas/as.sh
```

# 常用命令

## dashboard
显示进程信息,包含部分线程信息,内存信息,gc信息,部分系统信息,如果是tomcat还会显示tomcat的实时信息.该界面会一直刷新数据按`CTRL+C`中断.

默认刷新速率是每5秒刷新一次.



常用参数:
```
dashboard [-b] [-h] [-i <value>] [-n <value>]

-n <value> 获取几次的数据
-i <value> 刷新间隔,单位为毫秒
```

## thread
显示线程状态,什么参数都不使用会打印所有线程的大致信息



常用参数:
```
thread [-h] [-b] [-i <value>] [-n <value>] [id]

-b 查找处于block状态的线程
-i <value> 根据value的时间(单位为毫秒)统计线程的cpu使用情况,给出线程cpu利用率
-n <value> 查看cpu占用率为前value的线程的堆栈信息
<id> 显示该线程id的线程的堆栈信息
```

## jvm
打印jvm的详细信息



## sysprop

打印jvm虚拟机系统属性



常用参数:
```
sysprop [-h] [property-name] [property-value]

<property-name> 显示具体的某个属性,可以使用tab进行补全
<property-name> <property-value> 修改属性值
```

## sysenv
打印系统环境变量



常用参数:
```
sysenv [-h] [env-name]

<env-name> 显示具体的某个变量,可以使用tab进行补全
```

## mbean

查看java虚拟机JMX数据Mbean,不加参数时显示全部mbean列表



常用参数:
```
mbean [-h] [-i <value>] [-m] [-n <value>] [-E] [name-pattern] [attribute-pattern]

-i <value> 按照value(单位为毫秒)周期刷新显示
-m 显示详细的原始数据,在指定name-pattern的情况下有效
-n <value> 显示value次的数据
-E 匹配规则按照正则表达式匹配
[name-pattern] mbean的objectName的匹配规则,支持*通配符
[attribute-pattern] mbean的属性的匹配规则,支持*通配符,没有情况下显示全部信息
```

## getstatic
查看静态常量信息,功能较为简单,官方建议如果由复杂的查询需要使用ognl进行查询



常用参数:
```
getstatic [-c <value>] [-x <value>] [-h] [-E] class-pattern field-pattern [express]

-c <value> 通过classloader的hashCode指定classloader
-x <value> 对象参数展开级别,默认为1,即只显示该对象的属性,不会显示对象属性的属性
-E 匹配规则改为正则表达式匹配
class-pattern 类规则,支持*通配符
field-pattern 属性规则,支持*通配符
express 具体内容过滤,使用ognl编写表达式
```

## sc
查看所有已经加载的类



常用参数:
```
sc [-d] [-x <value>] [-f] [-h] [-E] class-pattern

-d 显示类信息
-x <value> 对象参数展开级别,默认为0,即不展开
-f 显示属性,需要和-d一起使用
-E 匹配规则改为正则表达式匹配
class-pattern 类规则,支持*通配符
```

## sm
查看类的方法信息



常用参数:
```
sm [-d] [-h] [-E] class-pattern [method-pattern]

-d 显示方法的详细信息
-E 匹配规则改为正则表达式匹配
class-pattern 类规则,支持*通配符
[method-pattern] 方法规则,支持*通配符
```

## dump
从虚拟机中将类的class文件提取出来



常用参数:
```
dump [-c <value>] [-d <value>] [-h] [-E] class-pattern

-c <value> 通过classloader的hashCode指定classloader
-d <value> 设置class文件输出目录
-E 匹配规则改为正则表达式匹配
class-pattern 类规则,支持*通配符
```

## jad
反编译指定已加载类的源码



常用参数:
```
jad [-c <value>] [-h] [-E] [--source-only] class-pattern [method-name]

-c <value> 通过classloader的hashCode指定classloader
-E 匹配规则改为正则表达式匹配
[--source-only] 反编译时会带上classloader信息,该选项将只显示源码
class-pattern 类规则,支持*通配符
[method-name] 方法规则,支持*通配符
```

## classloader
显示classloader信息



常用参数:
```
classloader [-a] [-c <value>] [-h] [-i] [-l] [--load <value>] [-r <value>] [-t]

-a 显示全部被加载的类,数据量较大,谨慎使用
-c <value> 根据classloader的hashCode显示classloader所属的jar包路径,配合其他参数时显示该classloader的内容
-i 包含根加载器,测试没有发现差异
-l 根据具体的classloader对象显示信息,而不是对于classloader类显示
--load <value> 加载指定的类,需要和-c一起使用classloader
-r <value> 加载指定的资源,需要和-c一起使用指定classloader
-t 打印继承树
```

## cat
打印命令,和linux的cat一样效果

常用参数:
```
cat [--encoding <value>] [-h] files...

--encoding <value> 文件编码
files... 文件列表
```

## pwd
显示工作目录,和linux的pwd一样效果

工作目录为监控的程序的工作目录

# 高级命令

## ognl
执行ognl表达式



常用参数:
```
ognl [-c <value>] [-x <value>] [-h] express

-c <value> 通过classloader的hashCode指定classloader
-x <value> 对象参数展开级别,默认为1
express 表达式
```

ognl参考:
> https://alibaba.github.io/arthas/ognl
>
> https://commons.apache.org/proper/commons-ognl/language-guide.html
>
> https://github.com/alibaba/arthas/issues/11

## mc

内存编译器,编译Java文件为字节码文件,编译存在失败的可能性,如果失败可以在本地进行编译,然后上传至服务器

常用参数:
```
mc [-c <value>] [-d <value>] [--encoding <value>] [-h] sourcefiles...

-c <value> 通过hashcode指定classloader进行编译
-d <value> 字节码文件输出目录
--encoding <value> 源代码文件编码
sourcefiles... java文件列表
```

## redefine
加载外部的class文件,替换掉虚拟机中的类,不停机进行替换测试

注意: 替换到的类无法进行恢复(只能重启恢复),并且如果原本的类和新的类存在差异(类结构层面的差异,比如增加了新的方法),将导致替换失败

常用参数:
```
redefine [-c <value>] [-h] classfilePaths...

-c 通过hashcode指定classloader加载
classfilePaths... class文件列表
```

限制:
1. 不允许新增加field/method,会造成无法替换
2. 正在运行的函数,没有运行结束前时无法变为替换后的函数,比如跑在线程中没有结束的代码

## monitor

方法执行监控



常用参数:
```
monitor [-c <value>] [-h] [-n <value>] [-E] class-pattern method-pattern

-c <value> 监控周期,默认为一分钟
-n <value> 记录次数,一周期为一次
-E 匹配规则改为正则表达式匹配
class-pattern 类规则,支持*通配符
method-name 方法规则,支持*通配符
```

监控维度:
| 监控项    | 说明                       |
| --------- | -------------------------- |
| timestamp | 时间戳                     |
| class     | Java类                     |
| method    | 方法（构造方法、普通方法） |
| total     | 调用次数                   |
| success   | 成功次数                   |
| fail      | 失败次数                   |
| rt        | 平均RT                     |
| fail-rate | 失败率                     |

## watch

方法执行出入参具体情况监控



常用参数:
```
watch [-b] [-e] [-x <value>] [-f] [-h] [-n <value>] [-E] [-M <value>] [-s] class-pattern method-pattern express [condition-express]

-b 在方法执行前进行观察
-e 在发生异常后观察
-x <value> 对象展开级别,默认为1
-f 在方法结束(包含正常返回和异常返回)后进行观察(默认选项)
-n <value> 监控次数
-E 匹配规则改为正则表达式匹配
-M 返回结果大小限制(默认为10*1024*1024)
-s 在方法返回后进行观察
class-pattern 类规则,支持*通配符
method-name 方法规则,支持*通配符
express 观察表达式,ognl表达式,能够观察执行的入参出餐
[condition-express] 条件表达式,ognl表达式,符合表达式的显示
```

## trace
获取方法内部的调用路径,并输出方法路径上的每个节点上耗时



常用参数:
```
trace [-h] [-j] [-n <value>] [-p <value>] [-E] class-pattern method-pattern [condition-express]

-j 过滤掉jdk的函数
-n <value> 统计次数
-p <value> path tracing pattern
-E 匹配规则改为正则表达式匹配
class-pattern 类规则,支持*通配符
method-name 方法规则,支持*通配符
[condition-express] 条件表达式,ognl表达式,符合表达式的显示
```

## stack

输出方法的调用路径



常用参数:
```
stack [-h] [-n <value>] [-E] class-pattern [method-pattern] [condition-express]

-n <value> 统计次数
-E 匹配规则改为正则表达式匹配
class-pattern 类规则,支持*通配符
[method-name] 方法规则,支持*通配符
[condition-express] 条件表达式,ognl表达式,符合表达式的显示
```

## tt
TimeTunnel,方法执行数据的时空隧道，记录下指定方法每次调用的入参和返回信息，并能对这些不同的时间下调用进行观测



常用参数:
```
tt [-d] [--delete-all] [-x <value>] [-h] [-i <value>] [-n <value>] [-l] [-p] [-E] [--replay-interval <value>] [--replay-times <value>] [-s <value>] [-M <value>] [-t] [-w <value>] [class-pattern] [method-pattern] [condition-express]

-i <value> 指定记录
-d 删除某个记录,使用-i指定记录
--delete-all 删除所有记录
-x <value> 对象展开级别
-n <value> 调用次数,调用量过多的函数可能存在无法中断的情况,建议使用-n设定记录次数
-l 显示所有记录
-p 再次调用
-E 匹配规则改为正则表达式匹配
--replay-interval <value> 调用间隔
--replay-times <value> 调用次数
-s <value> 在记录中搜索,使用ognl表达式搜索
-M <value> 返回结果大小限制
-t 记录方法执行数据
-w <value> 观察表达式,使用ognl
[class-pattern] 类规则,支持*通配符
[method-pattern] 方法规则,支持*通配符
[condition-express] 条件表达式,ognl表达式,符合表达式的显示
```

# 管道

支持使用`|`进行管道连接,对结果进行进一步处理

支持命令
```
grep——搜索满足条件的结果
plaintext——将命令的结果去除ANSI颜色
wc——按行统计输出结果
```

# 异步
`arthas`仿照linux设计了异步调用

使用`&`将任务放到后台执行,这时console可以进行其他操作

使用命令`jobs`查看后台运行的任务

例:
```
$ jobs
[33]*
       Running           tt -t com.zznode.ssg.dao.service.BusinessService heartBeatSend &
       execution count : 2
       start time      : Mon Jul 29 15:03:37 CST 2019
       timeout date    : Tue Jul 30 15:03:37 CST 2019
       session         : efe3963e-0e2c-4786-b989-11d3694fa46e (current)
```

`[33]*`33为任务id,`*`号表示该任务由当前session创建

`execution count` 为调用次数

`timeout date`是超时的时间，到这个时间，任务将会自动超时退出

任务在后台执行或者暂停状态（ctrl + z暂停任务）时，执行fg 将可以把对应的任务转到前台继续执行。在前台执行时，无法在console中执行其他命令

当任务处于暂停状态时（ctrl + z暂停任务），执行bg 将可以把对应的任务在后台继续执行

非当前session创建的job，只能由当前session fg到前台执行

使用`>`和`>>`将输出结果重定向

可以使用`kill <jobs-id>`停止任务

注意:
1. 最多同时支持8个命令使用重定向将结果写日志
2. 请勿同时开启过多的后台异步命令，以免对目标JVM性能造成影响

# 退出

quit将退出会话,异步任务将继续执行

quit退出后想要再次进入可以执行`telnet 127.0.0.1 3658`

shutdown将退出arthas
